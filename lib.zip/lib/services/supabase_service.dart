import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static Future<void> init() async {
    await Supabase.initialize(
      url: 'https://dpkazvjfqymgghthguxq.supabase.co',           // ← aquí pegas tu URL de Supabase
      anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRwa2F6dmpmcXltZ2dodGhndXhxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ2ODEyMDQsImV4cCI6MjA4MDI1NzIwNH0.VCMFqGmLTv-ZJZ1-EWdFq6rgoQvAda57ZtpKjU9KeTo',  // ← aquí pegas tu anon public key
    );
  }

  static SupabaseClient get client => Supabase.instance.client;
}